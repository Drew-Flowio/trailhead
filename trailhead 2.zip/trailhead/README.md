# Trailhead — Hiking & Venue Guide

A Next.js 14 app that helps users discover real hiking trails and nearby venues powered by the Claude API.

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Add your API key

Copy `.env.local.example` to `.env.local` and add your Anthropic API key:

```bash
cp .env.local.example .env.local
```

Then edit `.env.local`:

```
ANTHROPIC_API_KEY=your_api_key_here
```

Get a key at [console.anthropic.com](https://console.anthropic.com).

### 3. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy

### Vercel (recommended)

1. Push this repo to GitHub
2. Import the repo at [vercel.com](https://vercel.com)
3. Add `ANTHROPIC_API_KEY` as an environment variable in the Vercel dashboard
4. Deploy

### Netlify

1. Push this repo to GitHub
2. Import at [app.netlify.com](https://app.netlify.com) — set build command `npm run build`, publish dir `.next`
3. Add `ANTHROPIC_API_KEY` in Site Settings → Environment Variables
4. Deploy

## Project structure

```
app/
  api/
    trails/route.ts   — server route: fetches trail data from Claude API
    venues/route.ts   — server route: fetches venue data from Claude API
  globals.css         — all site styles
  layout.tsx          — root layout (fonts, metadata)
  page.tsx            — homepage
components/
  TrailGuide.tsx      — full interactive client component
lib/
  types.ts            — TypeScript types (Trail, Venue)
```

## Features

- Search any geographic area for real hiking trails
- Filter by difficulty (easy / moderate / hard) and features (dog-friendly, waterfall, lake, paved, accessible)
- Select a trail to see elevation profile, stats, and estimated time
- Nearby venue guidance: food, coffee, parking, gear, bars
- Filter venues by category
- One-click Google Maps directions to trailhead
- Fully responsive — mobile and desktop
- API key kept server-side (never exposed to the browser)
