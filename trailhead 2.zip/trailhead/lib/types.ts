export interface Trail {
  name: string
  park: string
  city: string
  state: string
  distance_miles: number
  elevation_ft: number
  difficulty: 'easy' | 'moderate' | 'hard'
  loop: boolean
  features: string[]
  lat: number
  lng: number
}

export interface Venue {
  name: string
  category: 'food' | 'coffee' | 'parking' | 'gear' | 'bar'
  address: string
  distance_miles: number
  rating: number
  price: '$' | '$$' | '$$$'
  note: string
}
