import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const trail = req.nextUrl.searchParams.get('trail') || ''
  const city = req.nextUrl.searchParams.get('city') || 'Minneapolis'

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY || '',
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system:
        'You are a hiking and outdoor guide. Respond ONLY with valid JSON. No markdown, no backticks, no preamble.',
      messages: [
        {
          role: 'user',
          content: `List 8 real places very close to the trailhead of "${trail}" in ${city}. Mix of: parking, coffee, food, gear, bars. JSON: {"venues":[{"name":"...","category":"food|coffee|parking|gear|bar","address":"...","distance_miles":X,"rating":X,"price":"$|$$|$$$","note":"one short helpful tip"}]}. Only real businesses.`,
        },
      ],
    }),
  })

  const data = await res.json()
  const text = data.content?.find((b: { type: string }) => b.type === 'text')?.text || '{}'

  try {
    const parsed = JSON.parse(text.replace(/```json|```/g, '').trim())
    return NextResponse.json(parsed)
  } catch {
    return NextResponse.json({ venues: [] }, { status: 500 })
  }
}
