import { NextRequest, NextResponse } from 'next/server'

export async function GET(req: NextRequest) {
  const area = req.nextUrl.searchParams.get('area') || 'Minneapolis, MN'

  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY || '',
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1500,
      system:
        'You are a hiking and outdoor guide. Respond ONLY with valid JSON. No markdown, no backticks, no preamble.',
      messages: [
        {
          role: 'user',
          content: `List 8 real hiking trails near or in "${area}". Return JSON: {"trails":[{"name":"...","park":"...","city":"...","state":"...","distance_miles":X,"elevation_ft":X,"difficulty":"easy|moderate|hard","loop":true|false,"features":["lake","waterfall","forest","ridge","paved","dog-friendly","wheelchair"],"lat":X,"lng":X}]}. Only real trails with accurate data.`,
        },
      ],
    }),
  })

  const data = await res.json()
  const text = data.content?.find((b: { type: string }) => b.type === 'text')?.text || '{}'

  try {
    const parsed = JSON.parse(text.replace(/```json|```/g, '').trim())
    return NextResponse.json(parsed)
  } catch {
    return NextResponse.json({ trails: [] }, { status: 500 })
  }
}
