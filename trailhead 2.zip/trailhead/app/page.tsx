import TrailGuide from '@/components/TrailGuide'

export default function Home() {
  return <TrailGuide />
}
