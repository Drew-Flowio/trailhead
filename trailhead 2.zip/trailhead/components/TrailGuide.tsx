'use client'

import { useState, useEffect, useRef } from 'react'
import type { Trail, Venue } from '@/lib/types'

const ICON_MAP: Record<string, string> = {
  food: 'ti-soup',
  coffee: 'ti-coffee',
  parking: 'ti-parking',
  gear: 'ti-backpack',
  bar: 'ti-glass-full',
  default: 'ti-map-pin',
}

const BG_MAP: Record<string, string> = {
  food: '#EAF3DE',
  coffee: '#FAEEDA',
  parking: '#E6F1FB',
  gear: '#EEEDFE',
  bar: '#FBEAF0',
  default: '#F1EFE8',
}

const DIFF_PCT: Record<string, number> = { easy: 22, moderate: 55, hard: 85 }

type Difficulty = 'all' | 'easy' | 'moderate' | 'hard'
type VenueCategory = 'all' | 'food' | 'coffee' | 'parking' | 'gear' | 'bar'

export default function TrailGuide() {
  const [area, setArea] = useState('Minneapolis, MN')
  const [searchInput, setSearchInput] = useState('')
  const [trails, setTrails] = useState<Trail[]>([])
  const [filtered, setFiltered] = useState<Trail[]>([])
  const [selected, setSelected] = useState<Trail | null>(null)
  const [allVenues, setAllVenues] = useState<Venue[]>([])
  const [diff, setDiffState] = useState<Difficulty>('all')
  const [feats, setFeats] = useState<Set<string>>(new Set())
  const [vcat, setVcatState] = useState<VenueCategory>('all')
  const [trailsLoading, setTrailsLoading] = useState(true)
  const [venuesLoading, setVenuesLoading] = useState(false)
  const [sectionTitle, setSectionTitle] = useState('Trails near Minneapolis')
  const sidebarRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    loadTrails('Minneapolis, MN')
  }, [])

  useEffect(() => {
    let f = trails
    if (diff !== 'all') f = f.filter((t) => t.difficulty === diff)
    if (feats.size) f = f.filter((t) => [...feats].every((feat) => (t.features || []).includes(feat)))
    setFiltered(f)
  }, [trails, diff, feats])

  async function loadTrails(searchArea: string) {
    setTrailsLoading(true)
    setTrails([])
    setSelected(null)
    setAllVenues([])
    try {
      const res = await fetch(`/api/trails?area=${encodeURIComponent(searchArea)}`)
      const data = await res.json()
      setTrails(data.trails || [])
    } finally {
      setTrailsLoading(false)
    }
  }

  async function loadVenues(trail: Trail) {
    setVenuesLoading(true)
    setAllVenues([])
    setVcatState('all')
    try {
      const res = await fetch(
        `/api/venues?trail=${encodeURIComponent(trail.name)}&city=${encodeURIComponent(trail.city || 'Minneapolis')}`
      )
      const data = await res.json()
      setAllVenues(data.venues || [])
    } finally {
      setVenuesLoading(false)
    }
  }

  function triggerSearch() {
    const val = searchInput.trim()
    const newArea = val
      ? val + (val.match(/mn|minnesota|wi|wisconsin/i) ? '' : ', Minnesota')
      : 'Minneapolis, MN'
    setArea(newArea)
    setSectionTitle('Trails near ' + (val || 'Minneapolis'))
    setDiffState('all')
    setFeats(new Set())
    loadTrails(newArea)
  }

  function selectTrail(trail: Trail) {
    setSelected(trail)
    loadVenues(trail)
    if (window.innerWidth <= 768 && sidebarRef.current) {
      sidebarRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }

  function toggleFeat(feat: string) {
    setFeats((prev) => {
      const next = new Set(prev)
      next.has(feat) ? next.delete(feat) : next.add(feat)
      return next
    })
  }

  function openMaps(e: React.MouseEvent) {
    e.preventDefault()
    if (!selected) return
    const q = encodeURIComponent(`${selected.name} trailhead ${selected.city} ${selected.state}`)
    window.open(`https://www.google.com/maps/search/?api=1&query=${q}`, '_blank', 'noopener')
  }

  function estTime(miles: number) {
    const hrs = Math.round((miles / 2.5) * 10) / 10
    return hrs < 1 ? `${Math.round(hrs * 60)}m` : `${hrs}h`
  }

  function drawElevationPath(trail: Trail): { poly: string; fill: string } {
    const pts: [number, number][] = []
    const seed = trail.name.length * 7 + trail.elevation_ft
    for (let i = 0; i < 16; i++) {
      const x = 10 + (i / 15) * 300
      const noise = ((seed * (i + 3) * 2654435761) & 0xffffff) / 0xffffff
      const y = 88 - noise * Math.min(72, trail.elevation_ft / 10)
      pts.push([x, y])
    }
    const poly = pts.map((p) => p.join(',')).join(' ')
    const fill = `10,90 ${poly} 310,90`
    return { poly, fill }
  }

  const displayVenues = vcat === 'all' ? allVenues : allVenues.filter((v) => v.category === vcat)

  return (
    <>
      <nav className="nav">
        <a className="nav-logo" href="/">
          Trail<span>head</span>
        </a>
        <div className="nav-loc">
          <i className="ti ti-map-pin" style={{ fontSize: 14 }} aria-hidden="true" />
          <span>{area}</span>
        </div>
      </nav>

      <section className="hero" role="banner">
        <div className="hero-eyebrow">Hiking &amp; venue guide</div>
        <h1 className="hero-title">Find your trail. Know where to stop.</h1>
        <p className="hero-sub">Real trails, real places. Search any area to discover hikes and the venues around them.</p>
        <div className="hero-search">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && triggerSearch()}
            placeholder='Try "Boundary Waters" or "St. Croix River"…'
            aria-label="Search trails"
          />
          <button onClick={triggerSearch}>Search</button>
        </div>
        <div className="hero-bg" aria-hidden="true">▲</div>
      </section>

      <div className="filters-bar" role="toolbar" aria-label="Trail filters">
        <span className="filter-label">Difficulty</span>
        {(['all', 'easy', 'moderate', 'hard'] as Difficulty[]).map((d) => (
          <button
            key={d}
            className={`chip${diff === d ? ' active' : ''}`}
            onClick={() => setDiffState(d)}
          >
            {d === 'all' ? 'All' : d.charAt(0).toUpperCase() + d.slice(1)}
          </button>
        ))}
        <div className="filter-divider" />
        <span className="filter-label">Features</span>
        {['dog-friendly', 'waterfall', 'lake', 'paved', 'wheelchair'].map((f) => (
          <button
            key={f}
            className={`chip${feats.has(f) ? ' active' : ''}`}
            onClick={() => toggleFeat(f)}
          >
            {f === 'wheelchair' ? 'Accessible' : f.replace('-', ' ')}
          </button>
        ))}
      </div>

      <main className="main">
        <div className="layout">
          <div>
            <div className="section-hd">
              <h2 className="section-title">{sectionTitle}</h2>
              {!trailsLoading && (
                <span className="section-count">
                  {filtered.length} trail{filtered.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>

            {trailsLoading && (
              <div className="state-box">
                <i className="ti ti-loader" style={{ animation: 'spin 1s linear infinite' }} aria-hidden="true" />
                Finding trails…
                <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
              </div>
            )}

            {!trailsLoading && filtered.length === 0 && (
              <div className="state-box">
                <i className="ti ti-map-off" aria-hidden="true" />
                No trails found. Try adjusting your search or filters.
              </div>
            )}

            <div className="trail-grid">
              {filtered.map((trail) => (
                <div
                  key={trail.name}
                  className={`trail-card${selected?.name === trail.name ? ' selected' : ''}`}
                  onClick={() => selectTrail(trail)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && selectTrail(trail)}
                  aria-label={`${trail.name}, ${trail.difficulty}, ${trail.distance_miles} miles`}
                >
                  <div className="trail-name">{trail.name}</div>
                  <div className="trail-park">
                    <i className="ti ti-map-pin" style={{ fontSize: 11 }} aria-hidden="true" />
                    {trail.park || trail.city || ''}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span
                      className={`badge ${
                        trail.difficulty === 'easy'
                          ? 'badge-easy'
                          : trail.difficulty === 'moderate'
                          ? 'badge-mod'
                          : 'badge-hard'
                      }`}
                    >
                      {trail.difficulty}
                    </span>
                    <span style={{ fontSize: 11, color: 'var(--ink3)' }}>
                      {trail.loop ? 'Loop' : 'Out & back'}
                    </span>
                  </div>
                  <div className="trail-stats">
                    <span className="trail-stat">
                      <i className="ti ti-arrows-horizontal" style={{ fontSize: 11 }} aria-hidden="true" />
                      {trail.distance_miles} mi
                    </span>
                    <span className="trail-stat">
                      <i className="ti ti-trending-up" style={{ fontSize: 11 }} aria-hidden="true" />
                      +{trail.elevation_ft} ft
                    </span>
                  </div>
                  <div className="trail-feats">
                    {(trail.features || []).slice(0, 4).map((f) => (
                      <span key={f} className="feat-tag">{f}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <aside className="sidebar" ref={sidebarRef} aria-label="Trail detail">
            <div className="detail-panel">
              {!selected ? (
                <div className="detail-empty">
                  <i className="ti ti-hand-finger" aria-hidden="true" />
                  Select a trail to see details and nearby venues
                </div>
              ) : (
                <>
                  <div className="detail-hero">
                    <div className="detail-name">{selected.name}</div>
                    <div className="detail-loc">
                      <i className="ti ti-map-pin" style={{ fontSize: 12 }} aria-hidden="true" />
                      {selected.park} · {selected.city}, {selected.state}
                    </div>
                  </div>

                  <div className="chart-area" aria-label="Elevation profile">
                    {(() => {
                      const { poly, fill } = drawElevationPath(selected)
                      return (
                        <svg viewBox="0 0 320 100" height={100} style={{ display: 'block', width: '100%' }}>
                          <defs>
                            <linearGradient id="eg" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#2d5a3d" stopOpacity={0.18} />
                              <stop offset="100%" stopColor="#2d5a3d" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <polygon points={fill} fill="url(#eg)" />
                          <polyline
                            points={poly}
                            fill="none"
                            stroke="#2d5a3d"
                            strokeWidth={2}
                            strokeLinejoin="round"
                            strokeLinecap="round"
                          />
                          <circle cx={10} cy={88} r={4} fill="#EAF3DE" stroke="#3B6D11" strokeWidth={1.5} />
                          <circle cx={310} cy={88} r={4} fill="#FCEBEB" stroke="#A32D2D" strokeWidth={1.5} />
                          <text x={14} y={98} fontSize={9} fill="#8a8a84" fontFamily="Inter,sans-serif">Start</text>
                          <text x={285} y={98} fontSize={9} fill="#8a8a84" fontFamily="Inter,sans-serif">End</text>
                          <text x={10} y={10} fontSize={9} fill="#8a8a84" fontFamily="Inter,sans-serif">Elevation profile</text>
                        </svg>
                      )
                    })()}
                  </div>

                  <div className="stats-row">
                    <div className="stat-cell">
                      <div className="stat-lbl">Distance</div>
                      <div className="stat-val">
                        {selected.distance_miles}<span className="stat-unit"> mi</span>
                      </div>
                    </div>
                    <div className="stat-cell">
                      <div className="stat-lbl">Elevation</div>
                      <div className="stat-val">
                        +{selected.elevation_ft}<span className="stat-unit"> ft</span>
                      </div>
                    </div>
                    <div className="stat-cell">
                      <div className="stat-lbl">Est. time</div>
                      <div className="stat-val">{estTime(selected.distance_miles)}</div>
                    </div>
                  </div>

                  <div className="diff-row">
                    <span style={{ fontSize: 11, color: 'var(--ink3)', width: 56 }}>Easy</span>
                    <div className="diff-track">
                      <div
                        className="diff-fill"
                        style={{ width: `${DIFF_PCT[selected.difficulty] || 40}%` }}
                      />
                    </div>
                    <span style={{ fontSize: 11, color: 'var(--ink3)', width: 32, textAlign: 'right' }}>Hard</span>
                    <span style={{ fontSize: 11, fontWeight: 500, color: 'var(--ink2)', width: 60, textAlign: 'right' }}>
                      {selected.difficulty}
                    </span>
                  </div>

                  <div className="venues-section">
                    <div className="venues-hd">
                      <span className="venues-title">Nearby venues</span>
                      {!venuesLoading && allVenues.length > 0 && (
                        <span style={{ fontSize: 11, color: 'var(--ink3)' }}>
                          {allVenues.length} places
                        </span>
                      )}
                    </div>

                    <div className="vcat-scroll" role="toolbar" aria-label="Venue category filter">
                      {(['all', 'food', 'coffee', 'parking', 'gear', 'bar'] as VenueCategory[]).map((cat) => (
                        <button
                          key={cat}
                          className={`chip${vcat === cat ? ' active' : ''}`}
                          onClick={() => setVcatState(cat)}
                        >
                          {cat === 'all' ? 'All' : cat.charAt(0).toUpperCase() + cat.slice(1)}
                        </button>
                      ))}
                    </div>

                    {venuesLoading && (
                      <div className="state-box" style={{ padding: '20px' }}>
                        <i className="ti ti-loader" style={{ animation: 'spin 1s linear infinite' }} aria-hidden="true" />
                        Loading venues…
                      </div>
                    )}

                    {!venuesLoading && displayVenues.length === 0 && allVenues.length > 0 && (
                      <div className="state-box" style={{ padding: '20px' }}>
                        <i className="ti ti-building-off" aria-hidden="true" />
                        No venues for this filter.
                      </div>
                    )}

                    {displayVenues.map((venue) => (
                      <div
                        key={venue.name}
                        className="venue-row"
                        role="button"
                        tabIndex={0}
                        aria-label={`${venue.name}, ${venue.category}`}
                      >
                        <div
                          className="venue-icon"
                          style={{ background: BG_MAP[venue.category] || BG_MAP.default }}
                        >
                          <i
                            className={`ti ${ICON_MAP[venue.category] || ICON_MAP.default}`}
                            aria-hidden="true"
                          />
                        </div>
                        <div className="venue-info">
                          <div className="venue-name">{venue.name}</div>
                          <div className="venue-note">{venue.note || venue.address || ''}</div>
                        </div>
                        <div className="venue-right">
                          <div className="venue-dist">
                            {venue.distance_miles ? `${venue.distance_miles} mi` : ''}
                          </div>
                          <div className="venue-price">{venue.price || ''}</div>
                          <div className="venue-stars">
                            {venue.rating ? '★'.repeat(Math.round(venue.rating)) : ''}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="action-bar">
                    <a className="btn btn-primary" href="#" onClick={openMaps}>
                      <i className="ti ti-map-2" aria-hidden="true" /> Open in maps
                    </a>
                    <a
                      className="btn"
                      href={`https://claude.ai/new?q=${encodeURIComponent(
                        `Tell me more about ${selected.name} — best time to visit, what to bring, and trail conditions.`
                      )}`}
                      target="_blank"
                      rel="noopener"
                    >
                      <i className="ti ti-message" aria-hidden="true" /> Ask Claude
                    </a>
                  </div>
                </>
              )}
            </div>
          </aside>
        </div>
      </main>

      <footer>
        Built with real trail data via Claude AI —{' '}
        <a href="https://www.alltrails.com" target="_blank" rel="noopener">
          AllTrails
        </a>{' '}
        for more routes
      </footer>
    </>
  )
}
